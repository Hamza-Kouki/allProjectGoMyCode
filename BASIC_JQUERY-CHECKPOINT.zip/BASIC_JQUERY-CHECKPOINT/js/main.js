      $('#bold').click(function(){
    $('#abc').css("font-weight", "bold"); 
    });
      ////
      $('#italic').click(function(){
        $('#abc').css("font-style", 'italic'); 
    });
      ///

      $('#underlined').click(function(){
        $('#abc').css('text-decoration', 'underline'); 
    });
//////////////////////////////////
$("#selectBox").change(function() {
    $('#abc').css("font-family", $(this).val());

});
/////////////////////

$("#size").change(function() {
    $('#abc').css("font-size", $(this).val());
});